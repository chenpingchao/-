<?php

/**
  * ECSHOP鍗囩礆绋嬪簭瑾炶█鏂囦欢
  * ================================================= ===========================
  *鐗堟瑠鎵€鏈?005-2011涓婃捣鍟嗘淳缍茬怠绉戞妧鏈夐檺鍏?徃锛屼甫淇濈暀鎵€鏈夋瑠鍒┿€
  *缍茬珯鍦板潃: http://www.ecshop.com
  * ------------------------------------------------- ---------------------------
  *閫欎笉鏄?竴鍊嬭嚜鐢辫粺浠讹紒鎮ㄥ彧鑳藉湪涓嶇敤鏂煎晢妤?洰鐨勭殑鍓嶆彁涓嬪皪绋嬪簭浠ｇ⒓閫茶?淇?敼鍜
  *浣跨敤锛涗笉鍏佽ū灏嶇▼搴忎唬纰间互浠讳綍褰㈠紡浠讳綍鐩?殑鐨勫啀鐧煎竷銆
  * ================================================= ===========================
  * $Author: liubo $
  * $Date: 2008-07-16 14:54:08 +0800$
  * $Id: zh_tw_utf-8.php 16882 2009-12-14 09:22:19Z liubo $
*/

$_LANG['prev_step'] = '涓婁竴姝ワ細';
$_LANG['next_step'] = '涓嬩竴姝ワ細';
$_LANG['select_language_title'] = 'ECSHOP鍗囩礆绋嬪簭绗?姝?鍏?姝ラ伕鎿囪獮瑷€绶ㄧ⒓';
$_LANG['readme_title'] = 'ECSHOP鍗囩礆绋嬪簭绗?姝?鍏?姝ヨ?鏄庨爜';
$_LANG['checking_title'] = 'ECShop鍗囩礆绋嬪簭绗?姝?鍏?姝ョ挵澧冩?娓?;
$_LANG['check_system_environment'] = '妾㈡脯绯荤当鐠板?';

$_LANG['copyright'] = '&copy; 2005-2018 <a href="http://www.ecshop.com" target="_blank">涓婃捣鍟嗘淳缍茬怠绉戞妧鏈夐檺鍏?徃</a>銆備繚鐣欐墍鏈夋瑠鍒┿€ ';
$_LANG['is_last_version'] = '鎮ㄧ殑ECSHOP宸叉槸鏈€鏂扮増鏈?紝鐒￠渶鍗囩礆銆 ';

$_LANG['readme_page'] = '瑾?槑闋?;
$_LANG['notice'] = '鏈?▼搴忕敤鏂煎皣ECSHOP鍗囩礆鍒?strong>%s</strong>銆傝珛鍕垮繀鎸夌収浠ヤ笅鐨勫崌绱氭柟娉曢€茶?鍗囩礆锛屽惁鍓囧彲鑳界敘鐢熺劇娉曟仮寰╃殑寰屾灉銆傚?鏋滀綘宸茬稉鏁村悎浜嗚珫澹囪粺浠讹紝鏈??鍗囩礆灏囧彇娑堟暣鍚堬紝浠ュ緦鏈冨摗鏁村悎璜嬪埌ucenrer涓?€茶?鏁村悎銆 ';
$_LANG['usage1'] = '璜嬬⒑瑾嶅凡缍撳畨瑁濅簡UCenter锛屽惁鍓囷紝璜嬪埌<a href="http://www.discuz.com" target="_blank">Comsenz鐢㈠搧涓?績</a>涓嬭級涓︿笖瀹夎?锛岀劧寰屽啀绻肩簩銆 <br />';
$_LANG['usage2'] = '<a href="../admin">鐧婚寗寰屽彴</a>锛孅span style="color:red;font-weight:bold;font-size:18px;">鍌欎唤</span>鏁告摎搴?硣鏂欙紱';
$_LANG['usage3'] = '闂滈枆鐝炬湁鐨凟CSHOP %s绯荤当锛?;
$_LANG['usage4'] = '瑕嗚搵鎬т笂鍌矱CSHOP %s鐨勫叏閮ㄦ枃浠跺埌鏈嶅嫏鍣?紱';
$_LANG['usage5'] = '涓婂偝鏈?▼搴忓埌ECSHOP鎵€鍦ㄧ殑鐩?寗涓?紱';
$_LANG['usage6'] = '閬嬭?鏈?▼搴忥紝鐩村埌鍑虹従鍗囩礆瀹屾垚鐨勬彁绀恒€ ';
$_LANG['method'] = '鍗囩礆鏂规硶';
$_LANG['charset'] = '绶ㄧ⒓纰鸿獚';

$_LANG['faq'] = '甯歌?鍟忛?';

$_LANG['basic_config'] = '鍩烘湰閰嶇疆淇℃伅';
$_LANG['config_path'] = '閰嶇疆鏂囦欢璺?緫';
$_LANG['db_host'] = '鏁告摎搴?富姗?;
$_LANG['db_name'] = '鏁告摎搴?悕';
$_LANG['db_user'] = '鐢ㄦ埗鍚?;
$_LANG['db_pass'] = '瀵嗙⒓';
$_LANG['db_prefix'] = '琛ㄥ墠缍?;
$_LANG['timezone'] = '鏅傚崁瑷?疆';
$_LANG['cookie_path'] = 'COOKIE璺?緫';
$_LANG['admin_dir'] = '绠＄悊涓?績鏍硅矾寰?;

$_LANG['dir_priv_checking'] = '鐩?寗娆婇檺妾㈡脯';
$_LANG['template_writable_checking'] = '妯℃澘鍙??鎬ф?鏌?;
$_LANG['rename_priv_checking'] = '鐗瑰畾鐩?寗淇?敼娆婇檺妾㈡煡';
$_LANG['cannt_write'] = '涓嶅彲瀵?;
$_LANG['can_write'] = '鍙??';
$_LANG['cannt_modify'] = '涓嶅彲淇?敼';
$_LANG['not_exists'] = '涓嶅瓨鍦?;
$_LANG['recheck'] = '閲嶆柊妾㈡煡';
$_LANG['all_are_writable'] = '鎵€鏈夋ā鏉匡紝鍏ㄩ儴鍙??';

$_LANG['update_now'] = '绔嬪嵆鍗囩礆';
$_LANG['done'] = '鎭?枩锛屾偍宸茬稉鎴愬姛鍗囩礆鍒癊CSHOP <strong>%s</strong>';
$_LANG['upgrade_error_title'] = 'ECShop鍗囩礆绋嬪簭鍗囩礆澶辨晽';
$_LANG['upgrade_done_title'] = 'ECShop鍗囩礆绋嬪簭鍗囩礆鎴愬姛';
$_LANG['go_to_view_my_ecshop'] = '鍓嶅線ECSHOP棣栭爜';
$_LANG['go_to_view_control_panel'] = '鍓嶅線ECSHOP寰屽彴绠＄悊涓?績';
$_LANG['dir_readonly'] = '%s鏂囦欢涓嶅彲瀵?紝璜嬫?鏌ユ偍鐨勬湇鍕欏櫒瑷?疆銆 ';
$_LANG['monitor_title'] = '鍗囩礆绋嬪簭鐩ｈ?鍣?;
$_LANG['wait_please'] = '姝ｅ湪鍗囩礆涓?紝璜嬬◢鍊欌€︹€︹€︹€?;
$_LANG['js_error'] = '瀹㈡埗绔疛avaScript鑵虫湰鐧肩敓閷??銆 ';
$_LANG['create_ver_failed'] = '鍓靛缓鐗堟湰灏嶈薄澶辨晽';
$_LANG['goto_charset_convert'] = '杞夊悜锛氭暩鎿氬韩绶ㄧ⒓杞夋彌';
$_LANG['goto_members_import'] = '杞夊悜锛氬緸UCenter灏庡叆鏈冨摗鏁告摎';

/*瀹㈡埗绔疛S瑾炶█闋?/
$_LANG['js_languages']['display_detail'] = '椤?ず绱扮瘈';
$_LANG['js_languages']['exception'] = '鐧肩敓鐣板父';
$_LANG['js_languages']['hide_detail'] = '闅辫棌绱扮瘈';
$_LANG['js_languages']['suspension_points'] = '鈥︹€︹€︹€?;
$_LANG['js_languages']['initialize'] = '鍒濆?鍖?;
$_LANG['js_languages']['wait_please'] = '姝ｅ湪鍗囩礆涓?紝璜嬬◢鍊欌€︹€︹€︹€?;
$_LANG['js_languages']['has_been_stopped'] = '鍗囩礆閫茬▼宸蹭腑姝?;
$_LANG['js_languages']['is_last_version'] = '鎮ㄧ殑ECSHOP宸叉槸鏈€鏂扮増鏈?紝鐒￠渶鍗囩礆銆 ';
$_LANG['js_languages']['from'] = '姝ｅ湪寰?;
$_LANG['js_languages']['to'] = '鍗囩礆鍒?;
$_LANG['js_languages']['update_files'] = '鍗囩礆鏂囦欢';
$_LANG['js_languages']['update_structure'] = '鍗囩礆鏁告摎绲愭?';
$_LANG['js_languages']['update_others'] = '鍗囩礆鍏跺畠';
$_LANG['js_languages']['success'] = '瀹屾垚';
$_LANG['js_languages']['fail'] = '澶辨晽';
$_LANG['js_languages']['notice'] = '鍑洪尟';
$_LANG['js_languages']['dump_database'] = '鍌欎唤鏁告摎';
$_LANG['js_languages']['rollback'] = '鎭㈠京鏁告摎';
$_LANG['js_languages']['uc_api'] = '璜嬪～瀵玌Center鐨刄RL';
$_LANG['js_languages']['uc_ip'] = '璜嬪～瀵玌Center鐨処P';
$_LANG['js_languages']['uc_pwd'] = '璜嬪～瀵玌Center鍓靛?浜虹殑瀵嗙⒓';

/* UCenter瀹夎?閰嶇疆*/
$_LANG['configure_uc'] = '閰嶇疆UCenter';
$_LANG['check_ucenter'] = '濉??瀹岀暍锛岄€茶?涓嬩竴姝?;
$_LANG['ucapi'] = 'UCenter鐨刄RL锛?;
$_LANG['ucip'] = 'UCenter鐨処P锛?;
$_LANG['ucenter'] = '璜嬪～瀵玌Center鐩搁棞淇℃伅锛?;
$_LANG['ucfounderpw'] = 'UCenter鍓靛?浜哄瘑纰硷細';
$_LANG['uc_intro'] = 'UCenter鏄疌omsenz鍏?徃鐢㈠搧鐨勬牳蹇冩湇鍕欑▼搴忥紝Discuz! Board鐨勫畨瑁濆拰閬嬭?渚濊炒姝ょ▼搴忋€傚?鏋滄偍宸茬稉瀹夎?浜哢Center锛岃珛濉??浠ヤ笅淇℃伅銆傚惁鍓囷紝璜嬪埌<a href="http://www.discuz.com" target="_blank">Comsenz鐢㈠搧涓?績</a>涓嬭級涓︿笖瀹夎?锛岀劧寰屽啀绻肩簩銆 <br /><br />';
$_LANG['ucip_intro'] = '閫ｆ帴鐨勯亷绋嬩腑鍑轰簡榛炲晱椤岋紝璜嬫偍濉??鏈嶅嫏鍣↖P鍦板潃锛屽?鏋滄偍鐨刄C鑸嘐CShop瑁濆湪鍚屼竴鏈嶅嫏鍣ㄤ笂锛屾垜鍊戝缓璀版偍鍢楄│濉??127.0.0.1';

$_LANG['users_importto_ucenter'] = '鏈冨摗鏁告摎灏庡叆鍒癠Center';
$_LANG['user_startid'] = '鏈冨摗ID璧峰?鍊硷細';
$_LANG['user_startid_intro'] = '<p>姝よ捣濮嬫渻鍝?D鐐?s銆傚?鍘烮D鐐?88鐨勬渻鍝″皣璁婄偤%s+888鐨勫€笺€ </p><br /><p><span style="color:#F00;font-size:1.2em;font-weight:bold;">鎻愰啋锛氬皫鍏ユ渻鍝℃暩鎿氬墠璜嬫毇鍋滃悇鍊嬫噳鐢?濡侱iscuz !, SupeSite绛?</span></p><br />';
$_LANG['maxuid_err'] = '璧峰?鏈冨摗ID蹇呴爤澶ф柤绛夋柤';
$_LANG['ucenter_import_members'] = '灏庡叆鏈冨摗鏁告摎鍒癠Center';
$_LANG['ucenter_no_database'] = '<span style="color:#F00;font-size:1.5em;"><b>涓嶈兘閫ｆ帴鍒癠Center鐨勬暩鎿氬韩锛屽崌绱氫笉鑳藉畬鎴愶紝璜嬭伅绻??鐞嗗摗锛 </b></span>';
$_LANG['user_merge_method'] = '鏈冨摗鍚堜降鏂瑰紡锛?;
$_LANG['user_merge_method_1'] = '灏囪垏UC鐢ㄦ埗鍚嶅拰瀵嗙⒓鐩稿悓鐨勭敤鎴跺挤鍒剁偤鍚屼竴鐢ㄦ埗';
$_LANG['user_merge_method_2'] = '灏囪垏UC鐢ㄦ埗鍚嶅拰瀵嗙⒓鐩稿悓鐨勭敤鎴朵笉灏庡叆UC鐢ㄦ埗';
$_LANG['ucenter_not_match'] = '<span style="color:#F00;font-size:1.2em;"><b>UCenter鑸嘐CShop瀛楃?绶ㄧ⒓涓嶅尮閰嶏紝鍗囩礆涓嶈兘瀹屾垚锛岃珛鑱?公绠＄悊鍝★紒 </b></span>';

/*瑾炶█瀛楃?闆嗛伕鎿?/
$_LANG['lang_title'] = 'ECShop瑾炶█绶ㄧ⒓';
$_LANG['lang_description'] = '鑱叉槑';
$_LANG['lang_charset']['zh_cn_gbk'] = '绨￠珨涓?枃GBK';
$_LANG['lang_charset']['zh_cn_utf-8'] = '绨￠珨涓?枃UTF-8';
$_LANG['lang_charset']['zh_tw_utf-8'] = '绻侀珨涓?枃UTF-8';
$_LANG['lang_desc']['desc1'] = '璜嬬⒑瑾嶆偍鐨凟CShop绋嬪簭鑸囨偍閬告搰鐨勮獮瑷€绶ㄧ⒓涓€鑷达紱';
$_LANG['lang_desc']['desc2'] = '濡傛灉鎮ㄧ殑鏁告摎搴?垏ECShop绋嬪簭绶ㄧ⒓涓嶄竴鑷达紝鍙?互鍏堥€茶?鏁告摎搴?法纰艰綁鎻涖€ ';
$_LANG['lang_desc']['desc3'] = '<font color="red">濡傛灉鎮ㄦ槸寰濫CShop v2.6.0鐗堟湰閫茶?鍗囩礆锛屼甫閬告搰ECShop鎺ュ彛鏂瑰紡锛岃珛鍏堥€茶?鏈冨摗鏁告摎鐨勫皫鍏ワ紝鍚﹀墖鍘熸渻鍝″皣鐒℃硶鐧婚寗銆侟/font> ';

/*鐢ㄦ埗鎺ュ彛鎻掍欢瑾炶█闋?/
$_LANG['ui_title'] = '璜嬮伕鎿嘐CShop浣跨敤鐨勭敤鎴舵帴鍙ｆ彃浠?;
$_LANG['ui_ecshop'] = 'ECShop鏂瑰紡';
$_LANG['ui_ucenter'] = 'UCenter鏂瑰紡';



/*鍗囩礆鏂囦欢浣跨敤涓?枃鐨勮獮瑷€闋?/
$_LANG['update_v250']['zh_cn'] = array('甯虫埗娌栧€?, '甯虫埗鎻愭?', '璩艰卜鍟嗗搧', '瑷傚柈閫€娆?, 'init' => '鍒濆?鍖?);
$_LANG['update_v250']['zh_tw'] = array('甯虫埗娌栧€?, '甯虫埗鎻愭?', '璩艰卜鍟嗗搧', '瑷傚柈閫€娆?, 'init' => '鍒濆?鍖? );
$_LANG['update_v250']['en_us'] = array('saving', 'drawing', 'buying', 'refundment', 'init' => 'initialize');
?>