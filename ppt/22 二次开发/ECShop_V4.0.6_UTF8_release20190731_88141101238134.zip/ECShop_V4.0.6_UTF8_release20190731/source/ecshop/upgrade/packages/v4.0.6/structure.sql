-- --------------------------------------------------------

--
-- 表的结构 `ecs_shop_config`
--

INSERT INTO `ecs_shop_config` (`parent_id`, `code`, `type`, `store_range`, `store_dir`, `value`, `sort_order`)
VALUES
	(3, 'share_title', 'text', '', '', '在线商城', 1),
	(3, 'share_desc', 'text', '', '', '发现了一个好商城，赶紧来购买吧！', 1);
