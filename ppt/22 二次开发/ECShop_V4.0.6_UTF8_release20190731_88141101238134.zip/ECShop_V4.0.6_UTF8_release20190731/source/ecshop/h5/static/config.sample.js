const env = {  
  'API_HOST': 'http://api.ecm.precd.geek-zoo.net',
  // 'API_HOST': 'http://api.shopex.ecm.geek-zoo.net',
  'APP_NAME': 'Demo',
  'APP_DESC': 'This is a  demo',
  'APP_KEYWORDS': 'Demo, Shop',
  'DEBUG': false,
  'ENCRYPTED': false,
  'VERSION': '1.0.0', // API版本号
}